# Network Log Anomaly Detection System — Both Versions

## Version 1: `version1_steps_1_to_16/main.py`
A combined beginner-friendly version of the code learned so far. It uses your existing `sample_logs.txt`.

## Version 2: `complete_project/main.py`
An expanded project with validation, repeated failed-login detection, high-volume IP rules, grouped counts, a suspicious-event timeline, text/CSV reports, optional charts, and an optional machine-learning demo.

Start with Version 1 if you want to revise the steps. Use Version 2 when you are ready to explore the full project.
