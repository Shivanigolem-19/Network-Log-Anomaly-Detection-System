# Network Log Anomaly Detection System

## What's included
- `main.py`: complete project script
- `sample_logs.txt`: sample data in the format you've been using
- `requirements.txt`: optional libraries for charts and the exploratory ML extension

## Run the core project
1. Keep `main.py` and `sample_logs.txt` in the same folder.
2. Open the folder in VS Code.
3. Run `main.py` with Python.

The main rule-based analysis works with Python's standard library. If Matplotlib is not installed, the program skips the chart and continues.

## Optional libraries
In the VS Code terminal, run:

```bash
python -m pip install -r requirements.txt
```

To try the optional machine-learning demo, open `main.py` and uncomment this line near the bottom:

```python
# run_optional_ml(logs)
```

Change it to:

```python
run_optional_ml(logs)
```

The ML demo skips small datasets and is only for learning. It should not be treated as a dependable security detector.

## Input format
Each non-empty line should have four comma-separated fields:

`YYYY-MM-DD HH:MM:SS,IPv4 address,EVENT_TYPE,username`

Example:

`2026-10-24 10:01:15,192.168.1.25,LOGIN_FAILED,bob`

## Output files
- `summary_report.txt`: counts, alerts, and input validation notes
- `suspicious_timeline.csv`: timestamped events matched by the current rules
- `event_counts.png`: event count chart, if Matplotlib is installed

## Important
Thresholds are configurable at the top of `main.py`. An alert is a clue to investigate, not proof that an IP address is malicious. This is an educational project and not a production-grade intrusion detection system.
