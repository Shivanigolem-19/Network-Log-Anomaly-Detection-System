"""
Network Log Anomaly Detection System
Complete project version.

Core features use Python's standard library:
- Parse and validate log records
- Detect repeated failed logins
- Flag high-volume IP addresses
- Group events by IP and username
- Create a suspicious-event timeline
- Generate a text summary report and CSV timeline
- Optionally create a chart with Matplotlib
- Optionally run a basic Isolation Forest model with scikit-learn

Input CSV format (one record per line):
Timestamp,IP Address,Event Type,Username

This is an educational prototype. Alerts are indicators for investigation,
not proof that an IP address is malicious.
"""

from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import csv
import re

BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "sample_logs.txt"
REPORT_FILE = BASE_DIR / "summary_report.txt"
TIMELINE_FILE = BASE_DIR / "suspicious_timeline.csv"
CHART_FILE = BASE_DIR / "event_counts.png"

FAILED_LOGIN_THRESHOLD = 3
IP_VOLUME_THRESHOLD = 5
TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"

EXPECTED_FIELDS = ["Timestamp", "IP Address", "Event Type", "Username"]
IP_PATTERN = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")


def valid_ipv4(ip_text):
    """Check basic IPv4 formatting and range."""
    if not IP_PATTERN.match(ip_text):
        return False
    try:
        return all(0 <= int(part) <= 255 for part in ip_text.split("."))
    except ValueError:
        return False


def parse_logs(file_path):
    """Read log records and return (logs, errors)."""
    logs = []
    errors = []

    if not file_path.exists():
        raise FileNotFoundError(
            f"Could not find {file_path.name}. Keep it beside main.py."
        )

    with file_path.open("r", encoding="utf-8") as file:
        for line_number, raw_line in enumerate(file, start=1):
            line = raw_line.strip()
            if not line:
                continue

            parts = [part.strip() for part in line.split(",")]
            if len(parts) != 4:
                errors.append(
                    f"Line {line_number}: expected 4 comma-separated fields; skipped."
                )
                continue

            timestamp_text, ip, event_type, username = parts

            try:
                timestamp = datetime.strptime(timestamp_text, TIMESTAMP_FORMAT)
            except ValueError:
                errors.append(
                    f"Line {line_number}: invalid timestamp '{timestamp_text}'; skipped."
                )
                continue

            if not valid_ipv4(ip):
                errors.append(
                    f"Line {line_number}: invalid IPv4 address '{ip}'; skipped."
                )
                continue

            if not event_type or not username:
                errors.append(
                    f"Line {line_number}: event type or username is empty; skipped."
                )
                continue

            logs.append({
                "Timestamp": timestamp_text,
                "TimestampObject": timestamp,
                "IP Address": ip,
                "Event Type": event_type.upper(),
                "Username": username,
            })

    logs.sort(key=lambda record: record["TimestampObject"])
    return logs, errors


def analyze_logs(logs):
    """Analyze parsed records and return report data."""
    ip_counts = Counter(log["IP Address"] for log in logs)
    event_counts = Counter(log["Event Type"] for log in logs)
    user_counts = Counter(log["Username"] for log in logs)

    failed_by_ip = Counter(
        log["IP Address"] for log in logs
        if log["Event Type"] == "LOGIN_FAILED"
    )
    failed_by_user = Counter(
        log["Username"] for log in logs
        if log["Event Type"] == "LOGIN_FAILED"
    )

    alerts = []
    suspicious_events = []

    for ip, count in failed_by_ip.items():
        if count >= FAILED_LOGIN_THRESHOLD:
            message = (
                f"Repeated failed logins: {count} attempts from {ip} "
                f"(threshold: {FAILED_LOGIN_THRESHOLD})"
            )
            alerts.append(message)
            for log in logs:
                if log["IP Address"] == ip and log["Event Type"] == "LOGIN_FAILED":
                    suspicious_events.append({
                        "Timestamp": log["Timestamp"],
                        "IP Address": ip,
                        "Event Type": log["Event Type"],
                        "Username": log["Username"],
                        "Reason": f"{count} failed logins from this IP",
                    })

    for ip, count in ip_counts.items():
        if count > IP_VOLUME_THRESHOLD:
            alerts.append(
                f"High log volume: {count} records from {ip} "
                f"(threshold: more than {IP_VOLUME_THRESHOLD})"
            )
            # Include all records for this IP in the timeline.
            for log in logs:
                if log["IP Address"] == ip:
                    suspicious_events.append({
                        "Timestamp": log["Timestamp"],
                        "IP Address": ip,
                        "Event Type": log["Event Type"],
                        "Username": log["Username"],
                        "Reason": f"{count} total records from this IP",
                    })

    # Remove duplicate timeline rows while preserving their reasons.
    unique = {}
    for event in suspicious_events:
        key = (
            event["Timestamp"], event["IP Address"], event["Event Type"],
            event["Username"], event["Reason"]
        )
        unique[key] = event
    suspicious_events = sorted(unique.values(), key=lambda item: item["Timestamp"])

    by_ip = defaultdict(list)
    by_user = defaultdict(list)
    for log in logs:
        by_ip[log["IP Address"]].append(log)
        by_user[log["Username"]].append(log)

    return {
        "total_records": len(logs),
        "ip_counts": ip_counts,
        "event_counts": event_counts,
        "user_counts": user_counts,
        "failed_by_ip": failed_by_ip,
        "failed_by_user": failed_by_user,
        "alerts": alerts,
        "suspicious_events": suspicious_events,
        "by_ip": by_ip,
        "by_user": by_user,
    }


def write_timeline_csv(events, file_path):
    """Save suspicious events to a CSV file."""
    fieldnames = ["Timestamp", "IP Address", "Event Type", "Username", "Reason"]
    with file_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(events)


def write_summary_report(data, errors, file_path):
    """Write a readable text report."""
    with file_path.open("w", encoding="utf-8") as file:
        file.write("NETWORK LOG ANOMALY DETECTION REPORT\n")
        file.write("=" * 45 + "\n\n")
        file.write(f"Total valid records: {data['total_records']}\n")
        file.write(f"Invalid/skipped lines: {len(errors)}\n\n")

        file.write("EVENT COUNTS\n")
        file.write("-" * 45 + "\n")
        for event, count in data["event_counts"].most_common():
            file.write(f"{event}: {count}\n")

        file.write("\nRECORDS BY IP ADDRESS\n")
        file.write("-" * 45 + "\n")
        for ip, count in data["ip_counts"].most_common():
            file.write(f"{ip}: {count}\n")

        file.write("\nFAILED LOGINS BY IP ADDRESS\n")
        file.write("-" * 45 + "\n")
        if data["failed_by_ip"]:
            for ip, count in data["failed_by_ip"].most_common():
                file.write(f"{ip}: {count}\n")
        else:
            file.write("No failed logins found.\n")

        file.write("\nALERTS\n")
        file.write("-" * 45 + "\n")
        if data["alerts"]:
            for alert in data["alerts"]:
                file.write(f"- {alert}\n")
        else:
            file.write("No alerts triggered by the configured rules.\n")

        file.write("\nINPUT VALIDATION NOTES\n")
        file.write("-" * 45 + "\n")
        if errors:
            for error in errors:
                file.write(f"- {error}\n")
        else:
            file.write("No invalid lines found.\n")

        file.write(
            "\nNote: alerts are rule-based indicators, not proof of malicious activity.\n"
        )


def create_event_chart(event_counts, file_path):
    """Create a chart if Matplotlib is installed."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Matplotlib not installed; skipping chart.")
        return False

    if not event_counts:
        print("No events available to chart.")
        return False

    labels = list(event_counts.keys())
    values = list(event_counts.values())
    plt.figure(figsize=(8, 5))
    plt.bar(labels, values)
    plt.title("Network Log Event Counts")
    plt.xlabel("Event Type")
    plt.ylabel("Count")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(file_path)
    plt.close()
    return True


def run_optional_ml(logs):
    """
    Optional exploratory anomaly detection with Isolation Forest.
    Needs scikit-learn and pandas. Small datasets are not reliable for ML.
    """
    try:
        import pandas as pd
        from sklearn.ensemble import IsolationForest
    except ImportError:
        print("Optional ML skipped (install pandas and scikit-learn to enable it).")
        return

    if len(logs) < 10:
        print("Optional ML skipped: use at least 10 records for this demo.")
        print("Rule-based alerts still ran normally.")
        return

    rows = []
    for log in logs:
        rows.append({
            "ip_record_count": sum(
                1 for item in logs if item["IP Address"] == log["IP Address"]
            ),
            "failed_login_count": sum(
                1 for item in logs
                if item["IP Address"] == log["IP Address"]
                and item["Event Type"] == "LOGIN_FAILED"
            ),
            "username_record_count": sum(
                1 for item in logs if item["Username"] == log["Username"]
            ),
            "is_failed_login": int(log["Event Type"] == "LOGIN_FAILED"),
        })

    frame = pd.DataFrame(rows)
    model = IsolationForest(contamination="auto", random_state=42)
    predictions = model.fit_predict(frame)
    anomaly_count = int((predictions == -1).sum())
    print(f"Optional ML demo: model marked {anomaly_count} records as unusual.")
    print("Treat this as an experiment, not a reliable security verdict.")


def main():
    print("=" * 55)
    print("NETWORK LOG ANOMALY DETECTION SYSTEM")
    print("=" * 55)

    try:
        logs, errors = parse_logs(LOG_FILE)
    except FileNotFoundError as error:
        print("ERROR:", error)
        return

    data = analyze_logs(logs)

    print("Valid log records:", data["total_records"])
    print("Invalid/skipped lines:", len(errors))

    print("\nEVENT TYPE SUMMARY")
    print("-" * 45)
    for event, count in data["event_counts"].most_common():
        print(f"{event}: {count}")

    print("\nRECORDS BY IP ADDRESS")
    print("-" * 45)
    for ip, count in data["ip_counts"].most_common():
        print(f"{ip}: {count}")

    print("\nFAILED LOGIN ATTEMPTS BY IP")
    print("-" * 45)
    for ip, count in data["failed_by_ip"].most_common():
        print(f"{ip}: {count}")

    print("\nALERTS")
    print("-" * 45)
    if data["alerts"]:
        for alert in data["alerts"]:
            print("ALERT:", alert)
    else:
        print("No alerts triggered by the configured rules.")

    print("\nSUSPICIOUS EVENT TIMELINE")
    print("-" * 45)
    if data["suspicious_events"]:
        for event in data["suspicious_events"]:
            print(
                event["Timestamp"], "|", event["IP Address"], "|",
                event["Event Type"], "|", event["Username"], "|",
                event["Reason"]
            )
    else:
        print("No suspicious events matched the configured rules.")

    write_summary_report(data, errors, REPORT_FILE)
    write_timeline_csv(data["suspicious_events"], TIMELINE_FILE)
    print(f"\nSummary report saved to: {REPORT_FILE.name}")
    print(f"Suspicious timeline saved to: {TIMELINE_FILE.name}")

    if create_event_chart(data["event_counts"], CHART_FILE):
        print(f"Event chart saved to: {CHART_FILE.name}")

    # Optional ML is disabled by default to keep the first run simple.
    # Uncomment the next line after installing requirements.txt:
    # run_optional_ml(logs)

    print("\nDone. Review alerts and investigate before drawing conclusions.")


if __name__ == "__main__":
    main()
