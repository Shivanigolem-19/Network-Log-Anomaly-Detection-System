# Network Log Anomaly Detection System
# Version 1: Steps 1-16 combined
# Keep this Python file in the same folder as sample_logs.txt.

logs = []

# Step 2: Open the sample log file
with open("sample_logs.txt", "r", encoding="utf-8") as file:

    # Step 3: Read the file one line at a time
    for line in file:

        # Step 4: Remove extra whitespace and split the line
        parts = line.strip().split(",")

        # Step 5: Check whether the record has four fields
        if len(parts) != 4:
            print("Invalid log record:", line.strip())
            continue

        # Step 6: Create a dictionary for the current record
        log = {
            "Timestamp": parts[0],
            "IP Address": parts[1],
            "Event Type": parts[2],
            "Username": parts[3]
        }

        # Step 7: Add the dictionary to the list
        logs.append(log)


# Steps 8-9: Display the total number of records and each record
print("=" * 45)
print("NETWORK LOG ANOMALY DETECTION SYSTEM")
print("=" * 45)
print("Total log records:", len(logs))

print("\nALL LOG RECORDS")
print("-" * 45)

for log in logs:
    print("Timestamp:", log["Timestamp"])
    print("IP Address:", log["IP Address"])
    print("Event Type:", log["Event Type"])
    print("Username:", log["Username"])
    print("-" * 45)


# Step 10: Count failed login attempts by IP address
failed_attempts = {}

for log in logs:
    if log["Event Type"] == "LOGIN_FAILED":
        ip = log["IP Address"]

        if ip not in failed_attempts:
            failed_attempts[ip] = 0

        failed_attempts[ip] += 1


# Step 11: Detect repeated failed login attempts
print("\nSUSPICIOUS LOGIN ACTIVITY")
print("-" * 45)

found_failed_login_alert = False

for ip, count in failed_attempts.items():
    if count >= 3:
        found_failed_login_alert = True
        print("Alert! Repeated failed login attempts")
        print("IP Address:", ip)
        print("Failed attempts:", count)
        print("-" * 45)

if not found_failed_login_alert:
    print("No repeated failed-login alerts detected.")


# Step 12: Count all records by IP address
ip_count = {}

for log in logs:
    ip = log["IP Address"]

    if ip not in ip_count:
        ip_count[ip] = 0

    ip_count[ip] += 1

print("\nLOG RECORDS BY IP ADDRESS")
print("-" * 45)

for ip, count in ip_count.items():
    print("IP Address:", ip)
    print("Total Records:", count)
    print("-" * 45)


# Step 13: Find the most active IP address
if ip_count:
    highest_count = max(ip_count.values())
    print("\nHIGHEST COUNT OF RECORDS:", highest_count)
    print("-" * 45)

    print("\nMOST ACTIVE IP ADDRESS")
    print("-" * 45)

    for ip, count in ip_count.items():
        if count == highest_count:
            print("Most Active IP Address:", ip)
            print("Total Records:", highest_count)


# Step 14: Detect IP addresses with unusually many records
threshold = 5

print("\nUNUSUAL IP ACTIVITY")
print("-" * 45)

found_unusual_ip = False

for ip, count in ip_count.items():
    if count > threshold:
        found_unusual_ip = True
        print("Alert! Unusual activity detected")
        print("IP Address:", ip)
        print("Total Records:", count)
        print("-" * 45)

if not found_unusual_ip:
    print("No IP addresses exceeded the threshold of", threshold)


# Step 15: Count different event types
event_counts = {}

for log in logs:
    event = log["Event Type"]

    if event not in event_counts:
        event_counts[event] = 0

    event_counts[event] += 1

print("\nEVENT TYPE SUMMARY")
print("-" * 45)

for event, count in event_counts.items():
    print("Event Type:", event)
    print("Total Count:", count)
    print("-" * 45)


# Step 16: Find the highest event count
if event_counts:
    highest_event_count = max(event_counts.values())

    print("\nMOST COMMON EVENT COUNT")
    print("-" * 45)
    print("Highest count:", highest_event_count)

    print("\nMOST COMMON EVENT TYPE")
    print("-" * 45)

    for event, count in event_counts.items():
        if count == highest_event_count:
            print("Event Type:", event)
            print("Total Count:", count)
            print("-" * 45)
